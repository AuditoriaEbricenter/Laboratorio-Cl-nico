﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio
{
    class clasTipoUsuario
    {
        private static string scodigo;

        public static string Scodigo
        {
            get { return clasTipoUsuario.scodigo; }
            set { clasTipoUsuario.scodigo = value; }
        }

    }
}
