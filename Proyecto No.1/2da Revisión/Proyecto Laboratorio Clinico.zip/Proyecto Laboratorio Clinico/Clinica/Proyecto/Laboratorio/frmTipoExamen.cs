﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laboratorio
{
    /*
         * Programador y Analista: Dylan Corado
         * Fecha de Asignacion: 07 de Agosto
         * Fecha de Entrega: 10 de Agosto
        */
    public partial class frmTipoExamen : Form
    {
        public frmTipoExamen()
        {
            InitializeComponent();
        }
    }
}
